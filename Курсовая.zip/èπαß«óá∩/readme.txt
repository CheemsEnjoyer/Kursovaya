Сайт выложен на http://poggers.pythonanywhere.com
Выполнены вроде как все требования на 3, 4 и 5.